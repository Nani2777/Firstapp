var cid = location.search.substring(5);
importScripts("https://cdn-jp.gsecondscreen.com/static/webpushsw.js?cid="+cid);